/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sebas
 */
public class StudentEntry {
    private String studentID;
    private String studentFName;
    private String studentLName;

    public StudentEntry(String studentID, String studentFName, String studentLName) {
        this.studentID = studentID;
        this.studentFName = studentFName;
        this.studentLName = studentLName;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getStudentFName() {
        return studentFName;
    }

    public String getStudentLName() {
        return studentLName;
    }
    
    
    
    
    
}
