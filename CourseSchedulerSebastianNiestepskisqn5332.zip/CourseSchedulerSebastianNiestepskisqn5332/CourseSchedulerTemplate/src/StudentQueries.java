
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sebas
 */
public class StudentQueries {
    private static Connection connection;
    private static PreparedStatement addStudent;
    private static PreparedStatement getStudentList;
    private static ResultSet studentResultSet;
    
    public static void addStudent(StudentEntry student)
    {
        connection = DBConnection.getConnection();
        
        try
        {
            addStudent = connection.prepareStatement("insert into app.student (studentid, firstname, lastname) values (?, ?, ?)");
            addStudent.setString(1, student.getStudentID());
            addStudent.setString(2, student.getStudentFName());
            addStudent.setString(3, student.getStudentLName());
            addStudent.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
           
    }
    
    public static ArrayList<StudentEntry> getAllStudents(){
        
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        
        try
        {
            getStudentList = connection.prepareStatement("select * from app.student");
            studentResultSet = getStudentList.executeQuery();
            
            while (studentResultSet.next()){
                
                students.add(new StudentEntry(studentResultSet.getString("STUDENTID"), studentResultSet.getString("FIRSTNAME"), studentResultSet.getString("LASTNAME")));
            }
           
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        return students;
    }
   
   public static ArrayList<String> getAllStudentIDs()
   {
      connection = DBConnection.getConnection();
      ArrayList<String> students = new ArrayList<String>(); 
       try
        {
            getStudentList = connection.prepareStatement("select studentid from app.student");
            studentResultSet = getStudentList.executeQuery();
            
            while (studentResultSet.next()){
                
                students.add(studentResultSet.getString("STUDENTID"));
            }
           
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
      return students;
   }
}
