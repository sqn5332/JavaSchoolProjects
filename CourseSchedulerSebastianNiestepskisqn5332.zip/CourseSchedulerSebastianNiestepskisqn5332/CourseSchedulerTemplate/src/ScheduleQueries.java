
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sebas
 */
public class ScheduleQueries {
    private static Connection connection; 
    private static PreparedStatement addSchedule;
    private static PreparedStatement getScheduleList;
    private static ResultSet scheduleResultSet;
    
    
    public static void addScheduleEntry(ScheduleEntry entry){
        
        connection = DBConnection.getConnection();
        
        try
        {
            addSchedule = connection.prepareStatement("insert into app.schedule (semester, studentid, coursecode, status, timestamp) values (?, ?, ?, ?, ?)");
            addSchedule.setString(1, entry.getSemester());
            addSchedule.setString(2, entry.getStudentID());
            addSchedule.setString(3, entry.getCourseCode());
            addSchedule.setString(4, entry.getStatus());
            addSchedule.setTimestamp(5, entry.getCurrentTimestamp());
            addSchedule.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID){
        
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedule = new ArrayList<ScheduleEntry>();
        
        try
        {
            getScheduleList = connection.prepareStatement("select * from app.schedule where semester = ? and studentID = ?");
            getScheduleList.setString(1, semester);
            getScheduleList.setString(2, studentID);
            scheduleResultSet = getScheduleList.executeQuery();
            
            while(scheduleResultSet.next())
            {
                schedule.add(new ScheduleEntry(semester, scheduleResultSet.getString("COURSECODE"), studentID, scheduleResultSet.getString("STATUS"), scheduleResultSet.getTimestamp("TIMESTAMP")));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return schedule;
        
    }
    
    public static int getScheduledStudentCount(String currentSemester, String courseCode){
        
        connection = DBConnection.getConnection();
        int scheduledStudentCount = 0;
        
        try
        {
            getScheduleList = connection.prepareStatement("select * from app.schedule where status = ? and semester = ? and coursecode = ?");
            getScheduleList.setString(1, "S");
            getScheduleList.setString(2, currentSemester);
            getScheduleList.setString(3, courseCode);
            scheduleResultSet = getScheduleList.executeQuery();
            
            while(scheduleResultSet.next())
            {
                scheduledStudentCount += 1;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return scheduledStudentCount;
    }
    
        
}
    
    
